import React from 'react';
import { Link } from 'react-router-dom';
import { Settings, Globe, Clock, Camera, Wifi, Shield, Zap } from 'lucide-react';

const Home = () => {
  const highlights = [
    {
      icon: <Settings className="h-8 w-8 text-[#3B82F6]" />,
      title: 'OEM/ODM CCTV Solutions',
      description: 'Custom manufacturing and design'
    },
    {
      icon: <Globe className="h-8 w-8 text-[#3B82F6]" />,
      title: 'Global Service',
      description: 'Supplying security products worldwide'
    },
    {
      icon: <Clock className="h-8 w-8 text-[#3B82F6]" />,
      title: 'On-Time & On-Budget',
      description: 'Quality assurance and reliability'
    }
  ];

  const products = [
    {
      name: 'HD Analog Cameras',
      image: 'https://images.pexels.com/photos/430208/pexels-photo-430208.jpeg?auto=compress&cs=tinysrgb&w=500',
      description: 'High-definition analog surveillance'
    },
    {
      name: 'IP Cameras',
      image: 'https://images.pexels.com/photos/2280549/pexels-photo-2280549.jpeg?auto=compress&cs=tinysrgb&w=500',
      description: 'Network-connected smart cameras'
    },
    {
      name: 'WiFi Cameras',
      image: 'https://images.pexels.com/photos/1059114/pexels-photo-1059114.jpeg?auto=compress&cs=tinysrgb&w=500',
      description: 'Wireless security solutions'
    },
    {
      name: '4G Solar Wireless Cameras',
      image: 'https://images.pexels.com/photos/159298/gears-cogs-machine-machinery-159298.jpeg?auto=compress&cs=tinysrgb&w=500',
      description: 'Remote monitoring with solar power'
    },
    {
      name: 'Security Camera Systems',
      image: 'https://images.pexels.com/photos/2228570/pexels-photo-2228570.jpeg?auto=compress&cs=tinysrgb&w=500',
      description: 'Complete integrated packages'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#0A2540] to-[#3B82F6] text-white">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Trusted CCTV Solutions – <br />
              <span className="text-[#3B82F6]">Secure Your World</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-4xl mx-auto">
              Chiconom provides high-quality HD analog cameras, IP cameras, WiFi cameras, 
              4G solar wireless cameras, and complete security systems at affordable prices.
            </p>
            <Link
              to="/contact"
              className="inline-block bg-[#3B82F6] text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-600 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Get a Quote
            </Link>
          </div>
        </div>
      </section>

      {/* Key Highlights */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {highlights.map((highlight, index) => (
              <div key={index} className="text-center p-8 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow duration-300">
                <div className="flex justify-center mb-4">
                  {highlight.icon}
                </div>
                <h3 className="text-xl font-semibold text-[#0A2540] mb-2">{highlight.title}</h3>
                <p className="text-gray-600">{highlight.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0A2540] mb-4">Featured Products</h2>
            <p className="text-xl text-gray-600">Comprehensive security solutions for every need</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {products.map((product, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-[#0A2540] mb-2">{product.name}</h3>
                  <p className="text-gray-600 text-sm">{product.description}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link
              to="/products"
              className="inline-block bg-[#0A2540] text-white px-8 py-3 rounded-lg font-semibold hover:bg-gray-800 transition-colors duration-200"
            >
              View All Products
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-[#0A2540] mb-6">
                Leading CCTV Solutions Provider
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Based in Shenzhen, China, Chiconom delivers professional CCTV solutions worldwide. 
                We specialize in OEM/ODM manufacturing, providing reliable and affordable security 
                systems for homes, businesses, and communities.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Our commitment to innovation, quality, and customer satisfaction makes us a trusted 
                partner for security professionals globally.
              </p>
              <Link
                to="/about"
                className="inline-block bg-[#3B82F6] text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-600 transition-colors duration-200"
              >
                Learn More
              </Link>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/442150/pexels-photo-442150.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Security Systems"
                className="w-full h-96 object-cover rounded-lg shadow-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A2540] opacity-20 rounded-lg"></div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;