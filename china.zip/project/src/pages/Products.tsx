import React from 'react';

const Products = () => {
  const products = [
    {
      name: 'HD Analog Cameras',
      image: 'https://images.pexels.com/photos/430208/pexels-photo-430208.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Affordable and reliable video surveillance solutions with high-definition analog technology.',
      features: ['1080p HD resolution', 'Night vision capability', 'Weather-resistant housing', 'Easy installation']
    },
    {
      name: 'IP Cameras',
      image: 'https://images.pexels.com/photos/2280549/pexels-photo-2280549.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'High-definition, network-connected cameras with advanced features and remote access.',
      features: ['4K resolution options', 'Remote monitoring', 'Motion detection', 'Cloud storage compatible']
    },
    {
      name: 'WiFi Cameras',
      image: 'https://images.pexels.com/photos/1059114/pexels-photo-1059114.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Easy to install and manage wireless security cameras for modern homes and businesses.',
      features: ['Wireless connectivity', 'Mobile app control', 'Two-way audio', 'Smart notifications']
    },
    {
      name: '4G Solar Wireless Cameras',
      image: 'https://images.pexels.com/photos/159298/gears-cogs-machine-machinery-159298.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Outdoor and remote monitoring solutions powered by solar energy with 4G connectivity.',
      features: ['Solar-powered operation', '4G LTE connectivity', 'PIR motion detection', 'Long battery life']
    },
    {
      name: 'Complete CCTV Systems',
      image: 'https://images.pexels.com/photos/2228570/pexels-photo-2228570.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Integrated packages for businesses and homes with all necessary components included.',
      features: ['Multi-camera setup', 'Central monitoring', 'Professional installation', 'Complete package deals']
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#0A2540] to-[#3B82F6] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Products</h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Comprehensive range of security cameras and surveillance systems
          </p>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {products.map((product, index) => (
              <div key={index} className="bg-gray-50 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden">
                <div className="md:flex">
                  <div className="md:w-1/2">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-64 md:h-full object-cover"
                    />
                  </div>
                  <div className="md:w-1/2 p-8">
                    <h3 className="text-2xl font-bold text-[#0A2540] mb-4">{product.name}</h3>
                    <p className="text-gray-600 mb-6 leading-relaxed">{product.description}</p>
                    <ul className="space-y-2">
                      {product.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center text-gray-700">
                          <div className="w-2 h-2 bg-[#3B82F6] rounded-full mr-3"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <button className="mt-6 bg-[#3B82F6] text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-600 transition-colors duration-200">
                      Learn More
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Product Categories */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0A2540] mb-4">Product Categories</h2>
            <p className="text-xl text-gray-600">Find the perfect security solution for your needs</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <h3 className="text-xl font-semibold text-[#0A2540] mb-4">Indoor Cameras</h3>
              <p className="text-gray-600 mb-4">Perfect for monitoring indoor spaces with discreet designs and advanced features.</p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• Dome cameras</li>
                <li>• Pan-tilt-zoom cameras</li>
                <li>• Hidden cameras</li>
              </ul>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <h3 className="text-xl font-semibold text-[#0A2540] mb-4">Outdoor Cameras</h3>
              <p className="text-gray-600 mb-4">Weather-resistant cameras designed for outdoor surveillance and monitoring.</p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• Bullet cameras</li>
                <li>• Solar-powered cameras</li>
                <li>• Night vision cameras</li>
              </ul>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <h3 className="text-xl font-semibold text-[#0A2540] mb-4">Specialty Cameras</h3>
              <p className="text-gray-600 mb-4">Specialized cameras for unique applications and challenging environments.</p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• Thermal cameras</li>
                <li>• License plate cameras</li>
                <li>• Explosion-proof cameras</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0A2540] mb-4">Technical Specifications</h2>
            <p className="text-xl text-gray-600">Industry-leading specifications and features</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="bg-[#3B82F6] text-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                <span className="text-lg font-bold">4K</span>
              </div>
              <h3 className="font-semibold text-[#0A2540]">Ultra HD</h3>
              <p className="text-sm text-gray-600">Maximum resolution</p>
            </div>
            <div>
              <div className="bg-[#3B82F6] text-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                <span className="text-lg font-bold">H.265</span>
              </div>
              <h3 className="font-semibold text-[#0A2540]">Compression</h3>
              <p className="text-sm text-gray-600">Efficient encoding</p>
            </div>
            <div>
              <div className="bg-[#3B82F6] text-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                <span className="text-lg font-bold">IP67</span>
              </div>
              <h3 className="font-semibold text-[#0A2540]">Weather Rating</h3>
              <p className="text-sm text-gray-600">Fully waterproof</p>
            </div>
            <div>
              <div className="bg-[#3B82F6] text-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                <span className="text-lg font-bold">IR</span>
              </div>
              <h3 className="font-semibold text-[#0A2540]">Night Vision</h3>
              <p className="text-sm text-gray-600">Up to 100m range</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Products;