import React from 'react';
import { Lightbulb, Award, Users } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: <Lightbulb className="h-12 w-12 text-[#3B82F6]" />,
      title: 'Innovation',
      description: 'Continuously developing cutting-edge security technologies to stay ahead of emerging threats and market demands.'
    },
    {
      icon: <Award className="h-12 w-12 text-[#3B82F6]" />,
      title: 'Quality',
      description: 'Maintaining the highest standards in manufacturing and design to ensure reliable, long-lasting security solutions.'
    },
    {
      icon: <Users className="h-12 w-12 text-[#3B82F6]" />,
      title: 'Customer Satisfaction',
      description: 'Providing exceptional service and support to build lasting partnerships with our clients worldwide.'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#0A2540] to-[#3B82F6] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Who We Are</h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Your trusted partner in comprehensive CCTV and security solutions
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl font-bold text-[#0A2540] mb-6">Our Story</h2>
              <p className="text-lg text-gray-600 mb-6">
                Chiconom is a professional supplier of CCTV solutions, including HD analog cameras, 
                IP cameras, WiFi cameras, solar-powered 4G wireless cameras, and full security systems. 
                Based in Shenzhen, China, we deliver OEM/ODM solutions worldwide.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Our mission is to provide reliable, affordable, and high-quality security solutions 
                to protect homes, businesses, and communities. We understand that security is not 
                just about technology – it's about peace of mind.
              </p>
              <p className="text-lg text-gray-600">
                With years of experience in the security industry and a deep understanding of global 
                market needs, we've built a reputation for delivering solutions that combine 
                cutting-edge technology with practical functionality.
              </p>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/3862132/pexels-photo-3862132.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Chiconom Team"
                className="w-full h-96 object-cover rounded-lg shadow-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A2540] opacity-20 rounded-lg"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Company Values */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0A2540] mb-4">Our Values</h2>
            <p className="text-xl text-gray-600">The principles that guide everything we do</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 text-center">
                <div className="flex justify-center mb-6">
                  {value.icon}
                </div>
                <h3 className="text-2xl font-semibold text-[#0A2540] mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0A2540] mb-4">Why Choose Chiconom?</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="bg-[#3B82F6] text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">15+</span>
              </div>
              <h3 className="text-lg font-semibold text-[#0A2540] mb-2">Years Experience</h3>
              <p className="text-gray-600">Proven track record in security solutions</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-[#3B82F6] text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">50+</span>
              </div>
              <h3 className="text-lg font-semibold text-[#0A2540] mb-2">Countries Served</h3>
              <p className="text-gray-600">Global reach and international expertise</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-[#3B82F6] text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">24/7</span>
              </div>
              <h3 className="text-lg font-semibold text-[#0A2540] mb-2">Support</h3>
              <p className="text-gray-600">Round-the-clock customer assistance</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-[#3B82F6] text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">100%</span>
              </div>
              <h3 className="text-lg font-semibold text-[#0A2540] mb-2">Quality Assured</h3>
              <p className="text-gray-600">Rigorous testing and quality control</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;