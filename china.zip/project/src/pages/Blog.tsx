import React from 'react';

const Blog = () => {
  const blogPosts = [
    {
      title: 'Top 5 Benefits of IP Cameras',
      date: 'January 15, 2025',
      image: 'https://images.pexels.com/photos/2280549/pexels-photo-2280549.jpeg?auto=compress&cs=tinysrgb&w=400',
      excerpt: 'Discover why IP cameras are becoming the preferred choice for modern security systems. Learn about their advantages over traditional analog cameras.',
      category: 'Technology'
    },
    {
      title: 'How Solar 4G Cameras Improve Remote Security',
      date: 'January 10, 2025',
      image: 'https://images.pexels.com/photos/159298/gears-cogs-machine-machinery-159298.jpeg?auto=compress&cs=tinysrgb&w=400',
      excerpt: 'Explore the innovative features of solar-powered 4G cameras and how they provide reliable security monitoring in remote locations.',
      category: 'Innovation'
    },
    {
      title: 'WiFi vs Wired CCTV Systems: Which to Choose?',
      date: 'January 5, 2025',
      image: 'https://images.pexels.com/photos/442150/pexels-photo-442150.jpeg?auto=compress&cs=tinysrgb&w=400',
      excerpt: 'A comprehensive comparison of WiFi and wired CCTV systems to help you make the best choice for your security needs.',
      category: 'Guide'
    },
    {
      title: 'Night Vision Technology in Modern CCTV',
      date: 'December 28, 2024',
      image: 'https://images.pexels.com/photos/430208/pexels-photo-430208.jpeg?auto=compress&cs=tinysrgb&w=400',
      excerpt: 'Understanding the latest advancements in night vision technology and how it enhances security surveillance capabilities.',
      category: 'Technology'
    },
    {
      title: 'OEM vs ODM: Understanding the Difference',
      date: 'December 20, 2024',
      image: 'https://images.pexels.com/photos/3862132/pexels-photo-3862132.jpeg?auto=compress&cs=tinysrgb&w=400',
      excerpt: 'Learn about OEM and ODM manufacturing models and how they can benefit your security equipment business.',
      category: 'Business'
    },
    {
      title: 'Smart Home Security: Trends for 2025',
      date: 'December 15, 2024',
      image: 'https://images.pexels.com/photos/1059114/pexels-photo-1059114.jpeg?auto=compress&cs=tinysrgb&w=400',
      excerpt: 'Discover the emerging trends in smart home security systems and what to expect in the coming year.',
      category: 'Trends'
    }
  ];

  const categories = ['All', 'Technology', 'Innovation', 'Guide', 'Business', 'Trends'];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#0A2540] to-[#3B82F6] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Insights & Updates</h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Stay informed with the latest trends, technologies, and best practices in security systems
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category, index) => (
              <button
                key={index}
                className={`px-6 py-2 rounded-full font-medium transition-colors duration-200 ${
                  index === 0
                    ? 'bg-[#3B82F6] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <article key={index} className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <span className="bg-[#3B82F6] text-white text-xs px-3 py-1 rounded-full font-medium">
                      {post.category}
                    </span>
                    <span className="text-gray-500 text-sm ml-4">{post.date}</span>
                  </div>
                  <h3 className="text-xl font-bold text-[#0A2540] mb-3 hover:text-[#3B82F6] transition-colors cursor-pointer">
                    {post.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed mb-4">
                    {post.excerpt}
                  </p>
                  <button className="text-[#3B82F6] font-medium hover:text-blue-600 transition-colors duration-200">
                    Read More →
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-[#0A2540] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Stay Updated</h2>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for the latest security insights and product updates
          </p>
          <div className="max-w-md mx-auto flex flex-col sm:flex-row gap-4">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#3B82F6]"
            />
            <button className="bg-[#3B82F6] text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-600 transition-colors duration-200">
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;