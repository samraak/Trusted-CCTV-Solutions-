import React from 'react';
import { Link } from 'react-router-dom';
import { Settings, Wrench, Shield, Truck } from 'lucide-react';

const Solutions = () => {
  const solutions = [
    {
      icon: <Settings className="h-16 w-16 text-[#3B82F6]" />,
      title: 'CCTV OEM/ODM Solutions',
      description: 'Custom manufacturing and design services tailored to your specific requirements. We provide end-to-end solutions from concept to production.',
      features: ['Custom hardware design', 'Private labeling', 'Flexible manufacturing', 'Quality control']
    },
    {
      icon: <Wrench className="h-16 w-16 text-[#3B82F6]" />,
      title: 'Custom Camera Development',
      description: 'Specialized camera development for unique applications and environments. Our engineering team creates solutions that meet your exact specifications.',
      features: ['Tailored specifications', 'Advanced features', 'Specialized housing', 'Performance optimization']
    },
    {
      icon: <Shield className="h-16 w-16 text-[#3B82F6]" />,
      title: 'Security System Integration',
      description: 'Complete integration services for comprehensive security systems. We ensure all components work seamlessly together.',
      features: ['System design', 'Component integration', 'Testing & validation', 'Documentation']
    },
    {
      icon: <Truck className="h-16 w-16 text-[#3B82F6]" />,
      title: 'Global Shipping & Support',
      description: 'Worldwide shipping and ongoing support services to ensure your security systems operate at peak performance.',
      features: ['Global delivery', 'Technical support', 'Maintenance services', 'Training programs']
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#0A2540] to-[#3B82F6] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Solutions</h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Comprehensive CCTV and security solutions designed to meet your unique needs
          </p>
        </div>
      </section>

      {/* Solutions Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {solutions.map((solution, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-8 hover:shadow-lg transition-shadow duration-300">
                <div className="flex items-center mb-6">
                  {solution.icon}
                  <h3 className="text-2xl font-bold text-[#0A2540] ml-4">{solution.title}</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">{solution.description}</p>
                <ul className="space-y-2">
                  {solution.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-700">
                      <div className="w-2 h-2 bg-[#3B82F6] rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0A2540] mb-4">Our Process</h2>
            <p className="text-xl text-gray-600">How we deliver exceptional security solutions</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-[#3B82F6] text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">1</span>
              </div>
              <h3 className="text-lg font-semibold text-[#0A2540] mb-2">Consultation</h3>
              <p className="text-gray-600">Understanding your security requirements and challenges</p>
            </div>
            <div className="text-center">
              <div className="bg-[#3B82F6] text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">2</span>
              </div>
              <h3 className="text-lg font-semibold text-[#0A2540] mb-2">Design</h3>
              <p className="text-gray-600">Creating customized solutions tailored to your needs</p>
            </div>
            <div className="text-center">
              <div className="bg-[#3B82F6] text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">3</span>
              </div>
              <h3 className="text-lg font-semibold text-[#0A2540] mb-2">Manufacturing</h3>
              <p className="text-gray-600">Producing high-quality systems with rigorous testing</p>
            </div>
            <div className="text-center">
              <div className="bg-[#3B82F6] text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">4</span>
              </div>
              <h3 className="text-lg font-semibold text-[#0A2540] mb-2">Support</h3>
              <p className="text-gray-600">Ongoing assistance and maintenance services</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#0A2540] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Work With Us?</h2>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
            Let's discuss how our security solutions can protect what matters most to you.
          </p>
          <Link
            to="/contact"
            className="inline-block bg-[#3B82F6] text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-600 transition-all duration-300 transform hover:scale-105"
          >
            Work With Us
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Solutions;