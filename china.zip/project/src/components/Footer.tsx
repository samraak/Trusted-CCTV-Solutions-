import React from 'react';
import { Shield, Facebook, Twitter, Youtube, Linkedin } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-[#0A2540] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <Shield className="h-8 w-8 text-[#3B82F6]" />
              <span className="text-xl font-bold">Chiconom</span>
            </div>
            <p className="text-gray-300 mb-4">
              Professional supplier of CCTV solutions, including HD analog cameras, IP cameras, 
              WiFi cameras, and complete security systems. Based in Shenzhen, China.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-[#3B82F6] transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-[#3B82F6] transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-[#3B82F6] transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-[#3B82F6] transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-gray-300 hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/solutions" className="text-gray-300 hover:text-white transition-colors">Solutions</Link></li>
              <li><Link to="/products" className="text-gray-300 hover:text-white transition-colors">Products</Link></li>
              <li><Link to="/blog" className="text-gray-300 hover:text-white transition-colors">Blog</Link></li>
              <li><Link to="/contact" className="text-gray-300 hover:text-white transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-2 text-gray-300">
              <p>Owner: Cherry</p>
              <p>Location: Shenzhen, China</p>
              <p>Email: chiconomcameras@gmail.com</p>
              <p>WeChat: +86 198 6507 2067</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-gray-300 text-sm">
            © 2025 Chiconom. All rights reserved. | CCTV OEM/ODM Solutions Worldwide.
          </p>
          <div className="flex space-x-4 mt-4 sm:mt-0">
            <Link to="#" className="text-gray-300 hover:text-white text-sm transition-colors">
              Terms & Conditions
            </Link>
            <Link to="#" className="text-gray-300 hover:text-white text-sm transition-colors">
              Privacy Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;